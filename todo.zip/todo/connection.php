<?php
$con=mysqli_connect("localhost","root","","todo");
if(!isset($con)){
    echo "Database connection error";
}else{
    
};
?>